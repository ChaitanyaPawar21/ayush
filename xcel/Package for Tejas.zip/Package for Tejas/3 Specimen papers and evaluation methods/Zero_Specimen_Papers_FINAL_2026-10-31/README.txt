ZERO — ICSE Class X specimen papers: FINAL set            31 October 2026

The current final version of every specimen paper. Anything older is in
Backups/Superseded and should not be sent out.

  Physics      Phy BP v1, Phy BP v2, Phy 2027 v1, Phy 2027 v2
  Mathematics  Math BP v1, Math BP v2, Math 2027 v1, Math 2027 v2
  Chemistry    Chem BP v1, Chem BP v2   (the board has published no
               2027 Chemistry specimen, so there is no 2027 version)

  BP   = built on the blueprint of the 2018-2025 board papers
  2027 = built on the 2027 board specimen pattern

FOR THE ANALYSIS TEAM
  Level and Integration Tags for Review.xlsx
      Every question part with our cognitive level(s) and its integration
      beside it. One sheet per paper. Fill the green columns: Agree /
      Change / Unsure, and what it should be. Look first at:
        - "Changed": 30 Oct marks the 69 parts rewritten to raise the
          critical-thinking share; 31 Oct the 27 rewritten to remove a
          repeated method or to link ideas;
        - the blue Linked and Integrated parts.
      The "Same method as" column would flag two parts of one paper that
      test the same thing; it is empty now.
  How the levels are tagged.pdf       The cognitive-level rule.
  How integration is tagged.pdf       The integration rule, the board's
                                      figures and ours.

Changed on 31 October
  Answer keys checked against every question (all 436 parts), afternoon:
    Phy BP v2   Nine Section A answers did not fit their questions — written
                for earlier versions of them. Q2(i) now works the force out
                (F = 140 N); Q2(iii) now answers P, the conductor whose graph
                is straight; Q2(ii), (v), (vii), Q3(i), (ii), (v) and Q4(i)
                now answer what is asked.
    Phy 2027 v2 Q9(i)(b) reasoning corrected.
    Chem BP v1  Q4(i)(a) asked for "gram atomic volume" and defined it as
                22.4 L for one gram atom, which is wrong for gases such as
                hydrogen. Now gram molecular volume: one mole of any gas
                occupies 22.4 L at s.t.p.
    Printing    "ohmic" printed as "Ωic"; "sends x to" as "sends × to";
                4(25) and 5(30), meaning products, as 4²⁵ and 5³⁰; ion
                charges, a triple bond and a power written as words. All
                fixed, and the style check now catches each kind.
    Notes       The teacher notes in Phy 2027 v1 and v2 still gave the old
                48 % critical share and an Evaluation count; Math 2027 v1
                and v2 gave the old chapter weightage. All updated.
  All Maths papers    "pi" and "+or-" printed as words. They now print as
                      π and ± (540π cm³, 2πrh, ±6).
  All answer keys     "x" used as a times sign beside letters and words
                      ("force x distance", "2 x angle CAB") now prints as ×.
  Math 2027 v2 Q9(iii), Phy BP v1 Q2(vi)
                      Two set-out lines (a proportion, a nuclear equation)
                      printed "a(2)" and "->"; they now print a² and →.
  A new check reads every PDF for symbols printed as words.
  Integration tagged for all ten papers and for the board's two 2027
  specimens (Single / Linked / Integrated, and cross-chapter), with a check
  for a method tested twice in one paper.
  27 parts rewritten (question and answer key), listed in "How
  integration is tagged.pdf":
    - 16 places where a paper tested the same method twice, e.g. three
      echo calculations in Phy 2027 v1, the fuse from an appliance's power
      twice in each Phy BP paper. None remains.
    - Maths 2027 papers raised from 4 % to 10 % of marks linking ideas,
      the board's figure; every Physics paper now has questions where the
      student must find the link (12-18 % linked, board 14 %).
    - Critical-thinking shares unchanged: Physics 13-14 %, Maths 56-57 %.
  Physics answer keys now print μ and ρ, not "mu" and "rho".
  Found while preparing the questions for the bank:
    - Math BP v2 Q2(ii) said "In the figure" but no figure was printed, and
      its key gave angle ABC = 62°, which is angle ABD (angle ABC is 28°).
      The question now describes the circle in words and asks for angle
      ABD and angle BCD; the answers, 62° and 28°, are checked.
    - Six products in the Maths keys printed as powers, e.g. (n - 1)⁵⁰ for
      (n - 1) × 50; three Physics keys printed "theta"; one Maths key
      printed "root of". All corrected, and the style check now catches
      each of them.

Changed on 30 October (analysis team review)
  Math BP v2  Q6(i)   "Find the number" now reads "Find the number, given
                      that it is greater than 1", so it has one answer, 5/2.
  Chem BP v1  Q5(i)   Cryolite (not an ore) replaced by bauxite.
                      Answer unchanged: (a) aluminium (b) iron.
  Phy BP v2   Q9(i)   The second ice-in-water problem replaced by a
                      latent-heat question by steady heating (naphthalene),
                      so the paper no longer repeats Q4(iii).
  All papers          Angles written "degrees" printed as "°rees" in 12
                      places (Maths BP v1 and v2, two Physics answer keys).
                      Every angle now prints as 28°.
  Math BP v1, v2  Q3(iii) and its answer: the matrices printed as
                      "A = | | and B = | |" with the numbers scattered.
                      They now print as proper two-row matrices in
                      brackets, and every answer was recomputed.

  All Physics and     Raised to the board's critical-thinking share
  Maths papers        (Physics 13 %, Maths 56 %, measured on the board's
                      2027 specimens). 32 Physics sub-parts now ask the
                      student to reason to a conclusion (choose, judge a
                      claim, predict a change); 37 Maths parts now need
                      the method found, a graph drawn or a result judged.
                      Every answer was recomputed. Critical share now:
                      every Physics paper 14 %, every Maths paper 57 %.
                      Chemistry is unchanged: the board has published no
                      Chemistry specimen to measure against.

Marks, sections and chapter spread re-checked for all ten papers; the page
layout check located all 382 parts with no problems.
